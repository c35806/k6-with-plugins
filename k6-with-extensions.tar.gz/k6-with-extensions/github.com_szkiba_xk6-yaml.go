package main
import _ "github.com/szkiba/xk6-yaml"
