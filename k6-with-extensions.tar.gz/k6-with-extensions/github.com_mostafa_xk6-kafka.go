package main
import _ "github.com/mostafa/xk6-kafka"
