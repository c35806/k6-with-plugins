package main

import (
	k6cmd "go.k6.io/k6/cmd"

	// plug in k6 modules here
	// TODO: Create /modules/standard dir structure?
	// _ "go.k6.io/k6/modules/standard"
)

func main() {
	k6cmd.Execute()
}
