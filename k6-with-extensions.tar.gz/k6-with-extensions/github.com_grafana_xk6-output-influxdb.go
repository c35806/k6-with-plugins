package main
import _ "github.com/grafana/xk6-output-influxdb"
