package main
import _ "github.com/avitalique/xk6-file"
